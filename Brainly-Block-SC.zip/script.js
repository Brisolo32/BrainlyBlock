localStorage.removeItem('flexible-funnel-cycle-data')
localStorage.removeItem('flexible-funnel-previews')